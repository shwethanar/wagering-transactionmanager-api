package com.example.pptgenerator.main;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.pptgenerator.service.PptService;

@RestController
@RequestMapping("/ppt")
public class PptController {

    @Autowired
    private PptService pptService;

    @PostMapping("/generate")
    public String generatePpt(@RequestBody PptRequest pptRequest) {
        pptService.generatePpt(pptRequest.getJsonData(), pptRequest.getImagePath());
        return "PPT generated successfully";
    }

}
