package com.example.pptgenerator.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.xslf.usermodel.*;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;

@Service
public class PptService {

    public void generatePpt(String jsonData, String imagePath) {
        try {
            // Parse JSON data
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode = objectMapper.readTree(jsonData);

            // Create a new PowerPoint presentation
            XMLSlideShow ppt = new XMLSlideShow();

            // Title Slide
            JsonNode titleNode = rootNode.get("title");
            if (titleNode != null) {
                XSLFSlide titleSlide = ppt.createSlide();
                XSLFTextBox titleBox = titleSlide.createTextBox();
                titleBox.setText(titleNode.asText());
                titleBox.setAnchor(new java.awt.Rectangle(100, 100, 400, 50));
            }

            // Content Slides
            JsonNode slidesNode = rootNode.get("slides");
            if (slidesNode.isArray()) {
                for (JsonNode slide : slidesNode) {
                    String heading = slide.get("heading").asText();
                    String content = slide.get("content").asText();

                    XSLFSlide pptSlide = ppt.createSlide();

                    // Add Heading
                    XSLFTextBox headingBox = pptSlide.createTextBox();
                    headingBox.setText(heading);
                    headingBox.setAnchor(new java.awt.Rectangle(50, 50, 600, 50));

                    // Add Content
                    XSLFTextBox contentBox = pptSlide.createTextBox();
                    contentBox.setText(content);
                    contentBox.setAnchor(new java.awt.Rectangle(50, 150, 600, 300));
                }
            }

            // Add an Image
            File imageFile = new File(imagePath);
            if (imageFile.exists()) {
                XSLFSlide imageSlide = ppt.createSlide();
                byte[] pictureData = java.nio.file.Files.readAllBytes(imageFile.toPath());
                XSLFPictureData picture = ppt.addPicture(pictureData, XSLFPictureData.PictureType.JPEG);

                XSLFPictureShape pictureShape = imageSlide.createPicture(picture);
                pictureShape.setAnchor(new java.awt.Rectangle(100, 100, 400, 300));
            }

            // Save the PPT
            try (FileOutputStream out = new FileOutputStream("generated_presentation.pptx")) {
                ppt.write(out);
            }

            System.out.println("PPT generated successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
