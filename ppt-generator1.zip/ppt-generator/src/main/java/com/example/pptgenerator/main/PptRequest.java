package com.example.pptgenerator.main;

import java.util.List;

import org.apache.poi.sl.usermodel.Slide;

public class PptRequest {
    private String jsonData;
    private String imagePath;

    // Getters and Setters
    public String getJsonData() {
        return jsonData;
    }

    public void setJsonData(String jsonData) {
        this.jsonData = jsonData;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
    
    
}

   