package com.example.pptgenerator.model;

public class ApiResponse {
    private String message;
    private String filePath;

    public ApiResponse(String message, String filePath) {
        this.message = message;
        this.filePath = filePath;
    }

    // Getters and setters
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
}
