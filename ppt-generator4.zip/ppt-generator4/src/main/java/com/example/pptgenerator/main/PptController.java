package com.example.pptgenerator.main;

import java.io.File;
import java.io.FileInputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.pptgenerator.model.ApiResponse;
import com.example.pptgenerator.model.SlideData;
import com.example.pptgenerator.service.PptService;

@RestController
@RequestMapping("/api/v1/ppt")
public class PptController {

    @Autowired
    private PptService pptService;

	/*
	 * @PostMapping("/generateJson") public ResponseEntity<ApiResponse>
	 * generatePpt(@RequestBody SlideData slideData) { try { String filePath =
	 * pptService.generatePpt(slideData); return ResponseEntity.ok(new
	 * ApiResponse("PowerPoint generated successfully", filePath)); } catch
	 * (Exception e) { return ResponseEntity.status(500).body(new
	 * ApiResponse("Error generating PowerPoint", e.getMessage())); } }
	 */
    
    @PostMapping("/generate")
    public ResponseEntity<byte[]> generatePpt(@RequestBody SlideData slideData) {
        try {
            // Generate the PPT and get the file path
            String filePath = pptService.generatePpt(slideData);

            // Convert the file into a byte array
            File file = new File(filePath);
            FileInputStream fileInputStream = new FileInputStream(file);
            byte[] pptBytes = fileInputStream.readAllBytes();
            fileInputStream.close();

            // Set response headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
            headers.setContentDispositionFormData("attachment", "generated_slide.pptx");

            // Return the file as a response
            return new ResponseEntity<>(pptBytes, headers, HttpStatus.OK);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(("Error generating PPT: " + e.getMessage()).getBytes());
        }
    }
    
    
    
}

