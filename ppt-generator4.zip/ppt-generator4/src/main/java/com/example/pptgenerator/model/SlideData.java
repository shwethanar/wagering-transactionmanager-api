package com.example.pptgenerator.model;



import java.util.List;

public class SlideData {
    private TableData tableData;
    private String comments;
    private List<TextBoxData> textBoxes;

    public TableData getTableData() {
        return tableData;
    }

    public void setTableData(TableData tableData) {
        this.tableData = tableData;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public List<TextBoxData> getTextBoxes() {
        return textBoxes;
    }

    public void setTextBoxes(List<TextBoxData> textBoxes) {
        this.textBoxes = textBoxes;
    }
}

