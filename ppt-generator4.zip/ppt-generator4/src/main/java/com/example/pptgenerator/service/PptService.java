package com.example.pptgenerator.service;

import java.awt.Color;
import java.awt.Rectangle;
import java.io.FileOutputStream;


import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xslf.usermodel.XSLFTable;
import org.apache.poi.xslf.usermodel.XSLFTableCell;
import org.apache.poi.xslf.usermodel.XSLFTableRow;
import org.apache.poi.xslf.usermodel.XSLFTextBox;
import org.apache.poi.xslf.usermodel.XSLFTextRun;
import org.springframework.stereotype.Service;

import com.example.pptgenerator.model.SlideData;
import com.example.pptgenerator.model.TableData;
import com.example.pptgenerator.model.TextBoxData;



@Service
public class PptService {

    public String generatePpt(SlideData slideData) throws Exception {
        String outputFilePath = "generated_slide_" + System.currentTimeMillis() + ".pptx";
        Color whiteColor = new Color(255, 255, 255); // White
        Color blueColor = new Color(0, 102, 204);   // Custom Blue
        Color blackColor = new Color(0, 0, 0);      // Black
        
        
        try (XMLSlideShow ppt = new XMLSlideShow()) {
            XSLFSlide slide = ppt.createSlide();

            // Add table
            TableData tableData = slideData.getTableData();
            if (tableData != null) {
                XSLFTable table = slide.createTable();
                table.setAnchor(new Rectangle(50, 50, 600, 150));
                XSLFTableRow headerRow = table.addRow();
                tableData.getHeaders().forEach(header ->
                    addCellWithStyle(headerRow, header, new Color(255, 255, 255), new Color(0, 102, 204), 14.0)
                );

                for (var row : tableData.getRows()) {
                    XSLFTableRow dataRow = table.addRow();
                    row.forEach(cell ->
                        addCellWithStyle(dataRow, cell, new Color(0, 0, 0), new Color(255, 255, 255), 12.0)
                    );
                }
            }

            // Add comments
            if (slideData.getComments() != null) {
                XSLFTextBox commentsBox = slide.createTextBox();
                commentsBox.setAnchor(new Rectangle(50, 210, 600, 40));
                commentsBox.setFillColor(new Color(240, 240, 240));
                XSLFTextRun commentsRun = commentsBox.addNewTextParagraph().addNewTextRun();
                commentsRun.setText("Comments: " + slideData.getComments());
                commentsRun.setFontSize(12.0);
            }

            // Add text boxes
            int yPosition = 260;
            for (TextBoxData textBox : slideData.getTextBoxes()) {
                XSLFTextBox box = slide.createTextBox();
                box.setAnchor(new Rectangle(220, yPosition, 300, 100));
                XSLFTextRun run = box.addNewTextParagraph().addNewTextRun();
                run.setText(textBox.getHeader() + ": " + textBox.getContent());
                yPosition += 130;
            }

            // Save the slide
            try (FileOutputStream out = new FileOutputStream(outputFilePath)) {
                ppt.write(out);
            }
        }
        return outputFilePath;
    }

    private void addCellWithStyle(XSLFTableRow row, String text, Color textColor, Color bgColor, double fontSize) {
        XSLFTableCell cell = row.addCell();
        cell.setText(text);
        cell.setFillColor(bgColor); // Set background color
        XSLFTextRun run = cell.getTextParagraphs().get(0).getTextRuns().get(0);
        run.setFontColor(textColor); // Set text color
        run.setFontSize(fontSize); // Set font size
    }

}